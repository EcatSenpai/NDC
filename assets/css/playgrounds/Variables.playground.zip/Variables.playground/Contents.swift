
var name = "Noah"
print(name)
name = "Molly"
print(name)

let city = "Tokyo"
print(city)

var lastName: String = "Smith 🔥"
print(lastName)

var age: Int = 50
print(age - 25)

var pi: Double = 3.14159
print(pi)

let isSwiftCodingFun = true
print(isSwiftCodingFun)


var username = "NDC"
var myAge = 26.50
var favoriteLanguage = "Swift"
let isLearningSwift = true

print("Hello, my name is \(username), I am \(myAge) years old")
print("My favorite coding language is \(favoriteLanguage), am I learning swift? that is \(isLearningSwift) ")
