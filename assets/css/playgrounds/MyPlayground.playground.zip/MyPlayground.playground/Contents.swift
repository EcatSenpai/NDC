import UIKit

let greeting = "Hello, playground, my name is "
var name = "Noah"

var age = 18

name = "Mike"
name = "Scott"
print(greeting + name)

if age >= 18 {
    print("you are an adult")
}else{
    print("you are NOT an adult")
}

for i in 1...5 {
    print("We are on loop number \(i)")
}
